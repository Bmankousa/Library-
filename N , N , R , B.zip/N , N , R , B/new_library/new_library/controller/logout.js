function logout()
{
      localStorage.setItem('login_status', 0);
      window.open("login.html", '_self');
}

